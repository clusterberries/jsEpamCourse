$(document).ready(function() {
	// set necessary options and slide!
	$('.sliderImg').slide({
		leftButton: $('.prev img'), 
		rightButton: $('.next img')
	});
});